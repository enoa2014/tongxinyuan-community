module.exports=[38150,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_dashboard_page_actions_9d14b367.js.map