globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/5bcee453cc4bce6d.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/e1140cc73d7c6ca2.js",
    "static/chunks/14b79e657fa4466a.js",
    "static/chunks/turbopack-dc3b44941ed87582.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];