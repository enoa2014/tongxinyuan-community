module.exports=[33290,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)("html",{lang:"zh-CN",children:(0,b.jsx)("body",{className:"antialiased bg-background text-text font-sans",children:a})})}a.s(["default",()=>c,"metadata",0,{title:"同心源社区 | 关爱异地大病求医儿童家庭",description:"关爱大病儿童家庭，提供住宿、饮食与政策支持"}])}];

//# sourceMappingURL=app_layout_tsx_271801d7._.js.map